# History Detective Academy — The Lost Museum Archives

An interactive Early World History game for Grade 8. Students restore a scrambled
museum archive across 6 cases (25 challenges, ~15–20 min), practicing BCE/CE dating,
chronological ordering, time calculation, primary vs. secondary sources, evidence
evaluation, and written historical reasoning.

Runs fully offline in any browser — ideal for Chromebooks. No accounts, no server.

## Files

| File | Purpose |
|------|---------|
| `index.html` | The game, self-contained. This is what GitHub Pages serves. |
| `History Detective Academy STANDALONE.html` | Identical to `index.html` — a clearly named copy to download/share directly. |
| `History Detective Academy.dc.html` + `support.js` | Editable source (used to regenerate the standalone). |
| `History Detective Academy Walkthrough.dc.html` | A printable 8-page visual walkthrough of every screen. |

## Deploy to GitHub Pages (≈2 minutes)

1. In your repo (e.g. `feliciarodman-dev/MUSEUM`), click **Add file → Upload files**.
2. Drag in `index.html` and **Commit changes**.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source: Deploy from a branch**,
   **Branch: main**, folder **/(root)**, then **Save**.
5. Wait ~1 minute. Your game is live at:
   **`https://feliciarodman-dev.github.io/MUSEUM/`**
6. Share that link with students.

> The repo is public, so the game URL is publicly reachable. That is fine for a
> classroom link, but it is not private.

## Sharing without GitHub

Hand out `History Detective Academy STANDALONE.html` directly — email it, post it in
Google Classroom as a material, or drop it in Drive. Students open the file in Chrome;
it works with no internet connection.

## Collecting results

There is no backend. At the end of play, each student clicks
**"Download results (CSV)"** and submits the CSV to you (Classroom, email, or shared
drive). Each file includes: student name, date/time, rank, total score and percent,
time spent, a per-skill breakdown, the number of attempts per question, and the
student's written response. Open the CSVs in Google Sheets or import to your gradebook.

## Accessibility

Reduce-motion and large-text toggles are on the entry screen and the top bar during
play. The game is keyboard-navigable, and color is never the only signal (✓/✗ icons
accompany all correct/incorrect states).
